(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f07ee_next_dist_606fcd0e._.js",
  "static/chunks/app_ui_home_module_6dd21efa.css"
],
    source: "dynamic"
});
