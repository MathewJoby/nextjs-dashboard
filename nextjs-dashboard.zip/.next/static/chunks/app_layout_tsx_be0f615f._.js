(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__b94e0764._.css",
  "static/chunks/f07ee_next_dist_35a4b6e8._.js"
],
    source: "dynamic"
});
