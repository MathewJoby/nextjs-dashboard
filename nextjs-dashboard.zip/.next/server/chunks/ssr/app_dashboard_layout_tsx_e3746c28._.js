module.exports = {

"[project]/app/dashboard/layout.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=app_dashboard_layout_tsx_e3746c28._.js.map