globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/[root-of-the-server]__aec0a1fa._.js",
      "static/chunks/a14e7_react-dom_638ad3bb._.js",
      "static/chunks/node_modules__pnpm_51c25b77._.js",
      "static/chunks/[root-of-the-server]__49fd8634._.js",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_018f7436._.js"
    ],
    "/_error": [
      "static/chunks/[root-of-the-server]__3eaa2cc8._.js",
      "static/chunks/a14e7_react-dom_638ad3bb._.js",
      "static/chunks/node_modules__pnpm_51c25b77._.js",
      "static/chunks/[root-of-the-server]__923cb372._.js",
      "static/chunks/pages__error_5771e187._.js",
      "static/chunks/pages__error_4363c9f7._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/f07ee_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_727141ce._.js",
    "static/chunks/f07ee_next_dist_compiled_072afd38._.js",
    "static/chunks/f07ee_next_dist_client_5cf5dcf9._.js",
    "static/chunks/f07ee_next_dist_eb86032f._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_42fd111b._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];